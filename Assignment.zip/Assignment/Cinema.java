class Cinema{

String name;
Screen screens[];
int no_of_screens;

Cinema(String name,int no_of_screens){

this.name=name;
this.no_of_screens=no_of_screens;

screens=new Screen[no_of_screens];
 for(int i=0; i<screens.length; i++){

screens[i]=new Screen(String.format("Screen "+(i+1),0));
				   }


}
@Override

public String toString(){

StringBuilder str=new StringBuilder();

str.append(name).append("\n\n");

for(int i=0; i<screens.length; i++){

str.append(screens[i].toString());

}
return str.toString();
}

}