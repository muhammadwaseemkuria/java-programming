class CinemaCity{

String name;
int noofcinemas=1;
Cinema cinemas[];

CinemaCity(String name,int noofcinemas){

this.name=name;
this.noofcinemas=noofcinemas;

cinemas=new Cinema[noofcinemas];

for(int i=0; i<cinemas.length; i++){

cinemas[i]=new Cinema("Cinema 1",1);

}

}

@Override
public String toString(){

StringBuilder str=new StringBuilder();


str.append(name).append("\n");

str.append("\n=================\n");

for(int i=0; i<cinemas.length; i++){
str.append(cinemas[i].toString());
}
return str.toString();

}

}