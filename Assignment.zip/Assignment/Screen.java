class Screen{


double PRICE_PREMIUM;
int DEFAULT_NUM_ROWS;
double PRICE_RECLINER;
double PRICE_VIP;
double PRICE_REGULAR;
String name;
Seat seats[][];
int rows=3;

Screen(String name){
this.name=name;

seats=new Seat[rows][];

for(int i=0; i<seats.length; i++){
seats[i]=new Seat[3+i];

	for(int j=0; j<seats[i].length; j++){

	seats[i][j]=new Seat(String.format("%02d-%d",i,j),Seat.SeatType.STANDARD,500,true);

					}

				}

			}

public String toString(){

StringBuilder str=new StringBuilder();
str.append(name).append("\n");

	
	
for(int i=0; i<seats.length; i++){


	for(int j=0; j<seats[i].length; j++){

	str.append("[").append(seats[i][j]).append("] ");
	
					    }	
				  }
return str.toString();
}





/*

public boolean Cancel(int r, int c) {


}


	



public boolean Book(String s){


}

public void checkRow(int r){



}

public String getScreenName(){



}

public Seat getSeat(String s){



}


public int getAvailableSeatCount(){

	
}

public void setRowType(int,SeatType,double){


}

public void checkBound(int r,int c){


}


public Seat getSeat(int r, int c){


}

public boolean Book(int r,int c){


}


public int getTotalSeatCount(){



}

public void displayVerbose(){


}

public int[] buildDefaultRowLengths(int ){


}

public int getAvailableSeatCount(SeatType ){


}

public Seat findFirstAvailable(SeatType){


}


public boolean Cancel(String ){


}

public int getRowLength(int ){


}

public SeatTypefor(int r,int c){


}

public double priceFor(SeatType){


}

public int getRowCount(){


}

public Seat[] listAvailable(SeatType){


}


public void displayLayout(){


}


*/



	}

