class Demo{

public static void main(String args[]){

//Seat s =new Seat("001",Seat.SeatType.STANDARD,500,true);
//System.out.println(s);

//Screen s=new Screen();

CinemaCity c = new CinemaCity("LAHORE",1);
System.out.println(c);


 

					}

		}