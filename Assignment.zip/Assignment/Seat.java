class Seat{

	private String id;
	private SeatType type;
	private double price;
	private boolean isAvailable;

enum SeatType{

	STANDARD,VIP,BUSINESS,ECONOMY;

}




Seat(String id, SeatType type, double price, boolean isAvailable){
this.id=id;
this.type=type;
this.price=price;
this.isAvailable=isAvailable;

}

public String toString(){
return String.format("%s %s %.02f %b",id,type,price, isAvailable);
}


public boolean bookSeat(){

	if(isAvailable==true){
	isAvailable=false;
	return true;
			     }
else{

return false;

}


}



public String getId(){

return id;
}

public SeatType getSeatType(){

return type;

}

public boolean isAvailable(){

if(isAvailable==true){
	return true;
}
else{

return false;
	}
}

public boolean cancelBooking(){

if(isAvailable==false){
isAvailable=true;
return true;
		     }

else{
	return false;
	}


}

public void setSeatType(SeatType type){
this.type=type;

}

public void setPrice(double price){

this.price=price;
}






}