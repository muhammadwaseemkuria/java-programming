//Name:Muhammad Waseem
//Registration No:SP25-BCS-109
public class StudentTest{

public static void main(String args[]){

Student s;

s=new Student(String name, String email, double cgpa);
s.display(String name, String email, double cgpa);
s.setStudent(String name, String email, double cgpa)
s.getStudent(String name, String email, double cgpa)
s.Student(String name, String email, double cgpa)




}
}