public class Demo{
	public static void main(String args[]){

		Student s1 = new Student();
		System.out.println("Name: "+ s1.name+ ", Email: " + s1.email + ", CGPA: " + s1.CGPA);


	}




}